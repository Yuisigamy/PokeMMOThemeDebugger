# Build verification

- Pure Kotlin analyzer sources: compiled successfully with Kotlin/JVM 2.0.x in this environment.
- Smoke tests: passed.
- Android APK: not built in this environment because Android SDK and Gradle are not installed and outbound package downloads are unavailable.
- The Android project is configured for AGP 8.7.3, Kotlin 2.0.21, compileSdk 35, minSdk 26.
