package com.pokemmo.themedebugger.analyzer

import com.pokemmo.themedebugger.model.*
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class AnalyzerTests {
    private fun zip(vararg entries: Pair<String,String>): File {
        val f = File.createTempFile("theme-test", ".zip")
        ZipOutputStream(f.outputStream()).use { z -> entries.forEach { (name, content) -> z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray()); z.closeEntry() } }
        return f
    }
    private fun parse(f: File): XmlAnalyzer.Result {
        ZipFile(f).use { z -> val idx = FileAnalyzer().index(z).index; return XmlAnalyzer().parse(z, idx) }
    }

    @Test fun validXmlHasZeroErrors() {
        val p = parse(zip("theme.xml" to "<themes><theme name=\"ok\"/></themes>"))
        assertEquals(0, p.diagnostics.count { it.severity == Severity.ERROR })
    }
    @Test fun malformedXmlHasOneError() {
        val p = parse(zip("ui/example.xml" to "<theme><button></theme>"))
        assertEquals(1, p.diagnostics.count { it.severity == Severity.ERROR })
        assertEquals(2, p.diagnostics.first { it.severity == Severity.ERROR }.location?.line)
    }
    @Test fun missingReferenceIsErrorWithoutBaseline() {
        val p = parse(zip("theme.xml" to "<themes><theme name=\"a\" ref=\"missing\"/></themes>"))
        val d = ReferenceAnalyzer(null).resolve(p.definitions, p.references, p.files)
        assertEquals(1, d.count { it.severity == Severity.ERROR })
    }
    @Test fun inheritedReferenceIsWarning() {
        val p = parse(zip("theme.xml" to "<themes><theme name=\"a\" ref=\"base-name\"/></themes>"))
        val baseline = ThemeVersion("test", "test", "sha", "local", setOf("base-name"), emptyList())
        val d = ReferenceAnalyzer(baseline).resolve(p.definitions, p.references, p.files)
        assertEquals(1, d.count { it.severity == Severity.WARNING })
        assertEquals(0, d.count { it.severity == Severity.ERROR })
    }
    @Test fun atlasOutOfBoundsIsError() {
        val xml = "<themes><images file=\"img.png\"><area name=\"x\" xywh=\"9,9,5,5\"/></images></themes>"
        val p = parse(zip("gfx_ui.xml" to xml, "img.png" to png1x1()))
        val image = ImageAnalyzer().validate(ZipFile(zip("img.png" to png1x1())), listOf(ThemeFile("img.png", 0, "png", ResourceKind.IMAGE))).infos
        val d = AtlasAnalyzer().validate(p.regions, image)
        assertTrue(d.any { it.title == "Atlas fuera de límites" })
    }
    @Test fun inheritedFontWithRefIsOk() {
        val p = parse(zip("fonts.xml" to "<fonts><fontDef name=\"child\" ref=\"base\"/></fonts>"))
        val d = FontAnalyzer().validate(p.fonts, p.files, p.references)
        assertTrue(d.any { it.title == "Fuente heredada" && it.severity == Severity.OK })
    }
    @Test fun duplicateDefinitionIsWarningWhenOverwrite() {
        val p = parse(zip("a.xml" to "<themes><theme name=\"same\"/><theme name=\"same\" overwrite=\"true\"/></themes>"))
        val d = p.diagnostics.filter { it.title == "Posible sobrescritura intencional" }
        assertEquals(1, d.size)
    }
    private fun png1x1() = byteArrayOf(137.toByte(),80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,1,0,0,0,1,8,6,0,0,0,31,21,-60,-119)
}
