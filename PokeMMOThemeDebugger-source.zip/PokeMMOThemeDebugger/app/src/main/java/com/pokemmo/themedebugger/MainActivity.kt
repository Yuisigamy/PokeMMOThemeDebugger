package com.pokemmo.themedebugger

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pokemmo.themedebugger.comparison.ThemeComparator
import com.pokemmo.themedebugger.database.VersionRepository
import com.pokemmo.themedebugger.export.JsonReportExporter
import com.pokemmo.themedebugger.export.TextReportExporter
import com.pokemmo.themedebugger.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App() } }
}

@Composable
private fun App() {
    val context = LocalContext.current
    var themeUri by remember { mutableStateOf<Uri?>(null) }
    var referenceUri by remember { mutableStateOf<Uri?>(null) }
    var themeName by remember { mutableStateOf<String?>(null) }
    var referenceName by remember { mutableStateOf<String?>(null) }
    var report by remember { mutableStateOf<AnalysisReport?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var baseMessage by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val analyzer = remember { ThemeAnalyzer(context, VersionRepository(context)) }

    val basePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { runCatching {
            val json = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            VersionRepository(context).importManifest(json)
            baseMessage = "Base importado correctamente."
        }.onFailure { baseMessage = "No se pudo importar: ${it.message}" } }
    }
    val themePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { themeUri = uri; themeName = displayName(context, uri); report = null }
    }
    val referencePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { referenceUri = uri; referenceName = displayName(context, uri) }
    }
    val jsonExportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null && report != null) scope.launch { context.contentResolver.openOutputStream(uri)?.use { it.write(JsonReportExporter.export(report!!).toByteArray()) } }
    }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null && report != null) scope.launch { context.contentResolver.openOutputStream(uri)?.use { it.write(TextReportExporter.export(report!!).toByteArray()) } }
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("PokeMMO Theme Debugger") }) }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
                Text("Analiza un Theme de PokeMMO sin necesitar logs.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { themePicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Seleccionar Theme .zip") }
                Text("Theme seleccionado: ${themeName ?: "ninguno"}", modifier = Modifier.padding(vertical = 8.dp))
                OutlinedButton(onClick = { referencePicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Seleccionar Theme de referencia (opcional)") }
                Text("Referencia: ${referenceName ?: "baseline interno a8d7102"}", modifier = Modifier.padding(vertical = 8.dp))
                OutlinedButton(onClick = { basePicker.launch(arrayOf("application/json", "text/json", "*/*")) }) { Icon(Icons.Default.SystemUpdateAlt, null); Spacer(Modifier.width(8.dp)); Text("Actualizar base") }
                baseMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 4.dp)) }
                Button(enabled = themeUri != null && !busy, onClick = {
                    scope.launch {
                        busy = true; error = null; progress = "Preparando ZIP…"
                        runCatching {
                            val currentFile = copyUriToCache(context, themeUri!!, "theme-current.zip")
                            progress = "Analizando estructura, XML, referencias, imágenes y fuentes…"
                            var result = withContext(Dispatchers.Default) { analyzer.analyze(currentFile) }
                            if (referenceUri != null) {
                                val refFile = copyUriToCache(context, referenceUri!!, "theme-reference.zip")
                                progress = "Comparando con el Theme de referencia…"
                                val ref = withContext(Dispatchers.Default) { analyzer.analyze(refFile, baselineId = null) }
                                result = result.copy(comparison = ThemeComparator.compare(result.snapshot, ref.snapshot))
                            }
                            report = result; tab = 0
                        }.onFailure { error = it.message ?: it.javaClass.simpleName }
                        busy = false; progress = ""
                    }
                }) { Icon(Icons.Default.BugReport, null); Spacer(Modifier.width(8.dp)); Text("ANALIZAR") }
                if (busy) { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()); Text(progress, modifier = Modifier.padding(top = 6.dp)) }
                error?.let { Text("ERROR: $it", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
                report?.let { r ->
                    Spacer(Modifier.height(16.dp))
                    ResultView(r, tab, { tab = it }, query, { query = it }, onExport = { exportPicker.launch("PokeMMO-report.txt") }, onExportJson = { jsonExportPicker.launch("PokeMMO-report.json") })
                }
            }
        }
    }
}

@Composable
private fun ResultView(report: AnalysisReport, tab: Int, onTab: (Int) -> Unit, query: String, onQuery: (String) -> Unit, onExport: () -> Unit, onExportJson: () -> Unit) {
    val tabs = listOf("Resumen", "Errores", "Advertencias", "Recursos", "XML", "Comparación")
    TabRow(selectedTabIndex = tab) { tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { onTab(i) }, text = { Text(t) }) } }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AssistChip(onClick = onExport, label = { Text("Exportar TXT") }, leadingIcon = { Icon(Icons.Default.Share, null) })
        AssistChip(onClick = onExportJson, label = { Text("Exportar JSON") }, leadingIcon = { Icon(Icons.Default.DataObject, null) })
    }
    when (tab) {
        0 -> Summary(report)
        1 -> DiagnosticList(report.errors)
        2 -> DiagnosticList(report.warnings)
        3 -> ResourceList(report, query, onQuery)
        4 -> XmlList(report)
        5 -> ComparisonList(report.comparison)
    }
}

@Composable private fun Summary(r: AnalysisReport) {
    Spacer(Modifier.height(12.dp))
    val cards = listOf("Archivos analizados" to r.snapshot.index.files.size, "XML encontrados" to r.snapshot.index.xmlFiles.size, "Definiciones" to r.definitionCount, "Errores" to r.errors.size, "Advertencias" to r.warnings.size, "Comprobaciones OK" to r.okCount)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(cards) { (label, n) -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Text(n.toString(), fontWeight = FontWeight.Bold) } } } }
}

@Composable private fun DiagnosticList(list: List<Diagnostic>) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (list.isEmpty()) item { Text("No hay diagnósticos en esta categoría.", modifier = Modifier.padding(16.dp)) }
        items(list) { d ->
            val icon = when (d.severity) { Severity.CRITICAL, Severity.ERROR -> Icons.Default.Error; Severity.WARNING -> Icons.Default.Warning; Severity.INFO -> Icons.Default.Info; Severity.OK -> Icons.Default.CheckCircle }
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null); Spacer(Modifier.width(8.dp)); Text(d.title, fontWeight = FontWeight.Bold) }; Text(d.message); d.location?.let { Text("Archivo: $it") }; d.detail?.let { Text(it) }; d.suggestion?.let { Text("Sugerencia: $it") } } }
        }
    }
}

@Composable private fun ResourceList(r: AnalysisReport, query: String, onQuery: (String) -> Unit) {
    Column { OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), label = { Text("🔎 Buscar recurso…") }, singleLine = true)
        val defs = r.snapshot.definitions.filter { query.isBlank() || it.name.contains(query, true) }.take(200)
        val refsByTarget = r.snapshot.references.groupBy { it.target }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(defs) { d -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
                Text(d.name, fontWeight = FontWeight.Bold); Text("Tipo: ${d.kind}"); Text("Definido en: ${d.location}"); d.ref?.let { Text("ref: $it") }
                val uses = refsByTarget[d.name].orEmpty().map { it.location }.distinct().take(8)
                if (uses.isNotEmpty()) Text("Referenciado por: ${uses.joinToString()}")
            } } }
            items(r.snapshot.images.filter { query.isNotBlank() && it.path.contains(query, true) }.take(50)) { image ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) { Text(image.path, fontWeight = FontWeight.Bold); Text("Imagen ${image.format}: ${image.width} × ${image.height}") } }
            }
        }
    }
}
@Composable private fun XmlList(r: AnalysisReport) { LazyColumn { items(r.snapshot.index.xmlFiles) { Text(it, Modifier.padding(8.dp)) } } }
@Composable private fun ComparisonList(c: ComparisonResult?) { if (c == null) Text("No se seleccionó un segundo ZIP.", Modifier.padding(16.dp)) else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { item { Text("+ ${c.addedDefinitions.size} definiciones nuevas") }; item { Text("- ${c.removedDefinitions.size} definiciones eliminadas") }; item { Text("~ ${c.modifiedDefinitions.size} definiciones modificadas") }; item { Text("+ ${c.addedFiles.size} archivos añadidos") }; item { Text("- ${c.removedFiles.size} archivos eliminados") }; item { Text("~ ${c.modifiedFiles.size} archivos modificados") } } }

private fun displayName(context: Context, uri: Uri): String = context.contentResolver.query(uri, arrayOf("_display_name"), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else uri.lastPathSegment } ?: uri.lastPathSegment ?: "Theme.zip"
private fun copyUriToCache(context: Context, uri: Uri, name: String): File { val f = File(context.cacheDir, name); context.contentResolver.openInputStream(uri)!!.use { input -> f.outputStream().use(input::copyTo) }; return f }
