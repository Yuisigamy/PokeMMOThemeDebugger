package com.pokemmo.themedebugger.analyzer

import com.pokemmo.themedebugger.model.*

class FontAnalyzer {
    fun validate(fonts: List<FontInfo>, files: List<ThemeFile>, refs: List<ThemeReference>): List<Diagnostic> {
        val paths = files.map { it.path.trimStart('/') }.toSet(); val out = mutableListOf<Diagnostic>()
        fonts.forEach { f ->
            val filename = f.filename ?: return@forEach
            val normalized = filename.substringAfterLast("../").trimStart('/')
            if (f.definition.ref != null) out += Diagnostic(Severity.OK, "Fuente heredada", "La definición usa ref y no exige un archivo local propio.", f.definition.location, detail = "ref=${f.definition.ref}")
            else if (paths.contains(normalized) || paths.contains(filename.trimStart('/'))) out += Diagnostic(Severity.OK, "Fuente válida", "El archivo de fuente está presente.", f.definition.location)
            else out += Diagnostic(Severity.WARNING, "Fuente no localizada", "No se encontró '${f.filename}' con una coincidencia exacta en el ZIP. Puede usar una ruta relativa al Theme base.", f.definition.location,
                suggestion = "Comprueba el Theme base seleccionado antes de añadir la fuente al ZIP.")
        }
        return out
    }
}
