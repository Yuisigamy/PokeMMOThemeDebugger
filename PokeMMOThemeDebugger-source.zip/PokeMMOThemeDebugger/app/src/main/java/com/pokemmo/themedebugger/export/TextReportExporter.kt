package com.pokemmo.themedebugger.export

import com.pokemmo.themedebugger.model.*

object TextReportExporter {
    fun export(report: AnalysisReport): String = buildString {
        appendLine("PokeMMO Theme Debugger Report")
        appendLine("Theme: ${report.snapshot.name}")
        appendLine("Baseline: ${report.baseline?.id ?: "none"}")
        appendLine("Files: ${report.snapshot.index.files.size}")
        appendLine("XML: ${report.snapshot.index.xmlFiles.size}")
        appendLine("Definitions: ${report.definitionCount}")
        appendLine("Errors: ${report.errors.size}")
        appendLine("Warnings: ${report.warnings.size}")
        appendLine()
        report.snapshot.diagnostics.forEachIndexed { i, d ->
            appendLine("${d.severity} #${(i + 1).toString().padStart(3, '0')}")
            appendLine("${d.title}: ${d.message}")
            d.location?.let { appendLine("Location: $it") }
            d.detail?.let { appendLine("Detail: $it") }
            d.suggestion?.let { appendLine("Suggestion: $it") }
            appendLine()
        }
    }
}
