package com.pokemmo.themedebugger.comparison

import com.pokemmo.themedebugger.model.*

object ThemeComparator {
    fun compare(current: ThemeSnapshot, reference: ThemeSnapshot): ComparisonResult {
        val a = current.definitions.associateBy { it.name }; val b = reference.definitions.associateBy { it.name }
        val added = a.filterKeys { it !in b }.values.toList(); val removed = b.filterKeys { it !in a }.values.toList()
        val modified = a.keys.intersect(b.keys).mapNotNull { n -> if (signature(a[n]!!) != signature(b[n]!!)) a[n]!! to b[n]!! else null }
        val af = current.index.files.associateBy { it.path }; val bf = reference.index.files.associateBy { it.path }
        val addedFiles = af.filterKeys { it !in bf }.values.toList(); val removedFiles = bf.filterKeys { it !in af }.values.toList()
        val modifiedFiles = af.keys.intersect(bf.keys).mapNotNull { p -> if (af[p]!!.sha256 != null && bf[p]!!.sha256 != null && af[p]!!.sha256 != bf[p]!!.sha256) af[p]!! to bf[p]!! else null }
        return ComparisonResult(added, removed, modified, addedFiles, removedFiles, modifiedFiles)
    }
    private fun signature(d: ThemeDefinition) = listOf(d.kind,d.ref,d.overwrite,d.attributes.toSortedMap()).toString()
}
