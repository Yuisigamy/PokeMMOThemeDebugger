package com.pokemmo.themedebugger.analyzer

import android.content.Context
import com.pokemmo.themedebugger.database.VersionRepository
import com.pokemmo.themedebugger.model.*
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile

class ThemeAnalyzer(private val context: Context, private val versionRepository: VersionRepository) {
    fun analyze(zipFile: File, baselineId: String? = "a8d7102"): AnalysisReport {
        require(zipFile.extension.equals("zip", ignoreCase = true)) { "Selecciona un archivo .zip" }
        val version = baselineId?.let { versionRepository.find(it) }
        // Keep a private temporary extraction as requested; parsing remains ZIP-stream based to avoid unnecessary copies.
        extractToPrivate(zipFile)
        ZipFile(zipFile).use { zip ->
            val fileAnalyzer = FileAnalyzer()
            val indexResult = fileAnalyzer.index(zip)
            val xmlAnalyzer = XmlAnalyzer()
            val parsed = xmlAnalyzer.parse(zip, indexResult.index)
            val referenceAnalyzer = ReferenceAnalyzer(version)
            val refDiagnostics = referenceAnalyzer.resolve(parsed.definitions, parsed.references, parsed.files)
            val imageResult = ImageAnalyzer().validate(zip, parsed.files)
            val atlasDiagnostics = AtlasAnalyzer().validate(parsed.regions, imageResult.infos)
            val imageDiagnostics = imageResult.diagnostics
            val fontDiagnostics = FontAnalyzer().validate(parsed.fonts, parsed.files, parsed.references)
            val diagnostics = indexResult.diagnostics + parsed.diagnostics + refDiagnostics + atlasDiagnostics + imageDiagnostics + fontDiagnostics
            val snapshot = ThemeSnapshot(
                name = zipFile.name,
                index = indexResult.index,
                definitions = parsed.definitions,
                references = parsed.references,
                regions = parsed.regions,
                images = imageResult.infos,
                fonts = parsed.fonts,
                diagnostics = diagnostics,
                analyzedFiles = indexResult.index.files.size
            )
            return AnalysisReport(snapshot = snapshot, baseline = version)
        }
    }

    fun extractToPrivate(zipFile: File): File {
        val target = File(context.cacheDir, "themes/${System.currentTimeMillis()}").apply { mkdirs() }
        ZipFile(zipFile).use { zip ->
            zip.entries().asSequence().forEach { entry ->
                if (entry.isDirectory) return@forEach
                val out = File(target, entry.name)
                out.parentFile?.mkdirs()
                zip.getInputStream(entry).use { input -> out.outputStream().use(input::copyTo) }
            }
        }
        return target
    }
}
