package com.pokemmo.themedebugger.analyzer

import com.pokemmo.themedebugger.model.*

class AtlasAnalyzer {
    fun validate(regions: List<AtlasRegion>, images: List<ImageInfo>): List<Diagnostic> {
        val byPath = images.associateBy { it.path.trimStart('/') }
        val out = mutableListOf<Diagnostic>()
        regions.forEach { r ->
            val image = byPath[r.file.trimStart('/')]
            if (image == null) {
                out += Diagnostic(Severity.WARNING, "Atlas sin imagen local", "No se encontró localmente '${r.file}'. Puede depender de una ruta base/heredada.", r.location, suggestion = "Verifica el Theme base antes de corregirlo.")
                return@forEach
            }
            if (r.width == 0 || r.height == 0) out += Diagnostic(Severity.ERROR, "Atlas inválido", "Una región tiene ancho o alto igual a cero.", r.location, detail = "xywh=${r.x},${r.y},${r.width},${r.height}")
            if (r.width < 0 || r.height < 0) {
                // Official themes contain negative xywh values; report only as informational unless bounds are provably impossible.
                out += Diagnostic(Severity.INFO, "xywh especial", "La región usa una dimensión negativa; el baseline oficial contiene casos similares y no se marca automáticamente como error.", r.location, detail = "xywh=${r.x},${r.y},${r.width},${r.height}")
            }
            val right = r.x.toLong() + r.width
            val bottom = r.y.toLong() + r.height
            if (r.x < 0 || r.y < 0 || right > image.width || bottom > image.height) {
                if (r.width >= 0 && r.height >= 0) out += Diagnostic(Severity.ERROR, "Atlas fuera de límites", "La región excede las dimensiones de la imagen.", r.location,
                    detail = "xywh=${r.x},${r.y},${r.width},${r.height}; imagen=${image.width}×${image.height}")
            }
        }
        return out
    }
}
