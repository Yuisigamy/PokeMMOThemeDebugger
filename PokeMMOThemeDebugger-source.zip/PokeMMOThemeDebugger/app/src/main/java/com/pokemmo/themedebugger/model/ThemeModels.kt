package com.pokemmo.themedebugger.model

import java.security.MessageDigest

enum class Severity { CRITICAL, ERROR, WARNING, INFO, OK }
enum class ReferenceState { LOCAL, INHERITED, BROKEN, UNKNOWN }
enum class ResourceKind { DEFINITION, IMAGE, FONT, ATLAS, FILE }

data class Location(val file: String, val line: Int? = null, val column: Int? = null) {
    override fun toString(): String = buildString {
        append(file); line?.let { append(":").append(it) }; column?.let { append(":").append(it) }
    }
}

data class Diagnostic(
    val severity: Severity,
    val title: String,
    val message: String,
    val location: Location? = null,
    val detail: String? = null,
    val suggestion: String? = null,
    val fragment: String? = null
)

data class ThemeFile(
    val path: String,
    val size: Long,
    val extension: String,
    val kind: ResourceKind,
    val sha256: String? = null,
    val duplicate: Boolean = false
)

data class ThemeDefinition(
    val name: String,
    val kind: ResourceKind,
    val location: Location,
    val sourceFile: String,
    val ref: String? = null,
    val overwrite: Boolean = false,
    val attributes: Map<String, String> = emptyMap()
)

data class ThemeReference(
    val target: String,
    val kind: ResourceKind,
    val location: Location,
    val sourceFile: String,
    val syntax: String,
    var state: ReferenceState = ReferenceState.UNKNOWN
)

data class AtlasRegion(
    val name: String?,
    val file: String,
    val location: Location,
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int,
    val wildcard: Boolean = false
)

data class ImageInfo(val path: String, val width: Int, val height: Int, val format: String)
data class FontInfo(val definition: ThemeDefinition, val filename: String?)

data class ThemeIndex(
    val files: List<ThemeFile>,
    val xmlFiles: List<String>,
    val images: List<ThemeFile>,
    val fonts: List<ThemeFile>,
    val atlases: List<String>,
    val other: List<ThemeFile>,
    val duplicatePaths: Set<String>
)

data class ThemeSnapshot(
    val name: String,
    val index: ThemeIndex,
    val definitions: List<ThemeDefinition>,
    val references: List<ThemeReference>,
    val regions: List<AtlasRegion>,
    val images: List<ImageInfo>,
    val fonts: List<FontInfo>,
    val diagnostics: List<Diagnostic>,
    val analyzedFiles: Int
)

data class ThemeVersion(
    val id: String,
    val label: String,
    val fullCommit: String,
    val source: String,
    val knownDefinitions: Set<String>,
    val notes: List<String>
)

data class ComparisonResult(
    val addedDefinitions: List<ThemeDefinition>,
    val removedDefinitions: List<ThemeDefinition>,
    val modifiedDefinitions: List<Pair<ThemeDefinition, ThemeDefinition>>,
    val addedFiles: List<ThemeFile>,
    val removedFiles: List<ThemeFile>,
    val modifiedFiles: List<Pair<ThemeFile, ThemeFile>>
)

data class AnalysisReport(
    val snapshot: ThemeSnapshot,
    val comparison: ComparisonResult? = null,
    val baseline: ThemeVersion? = null
) {
    val errors get() = snapshot.diagnostics.filter { it.severity == Severity.ERROR || it.severity == Severity.CRITICAL }
    val warnings get() = snapshot.diagnostics.filter { it.severity == Severity.WARNING }
    val okCount get() = snapshot.diagnostics.count { it.severity == Severity.OK }
    val definitionCount get() = snapshot.definitions.size
}

fun ByteArray.sha256(): String = MessageDigest.getInstance("SHA-256").digest(this).joinToString("") { "%02x".format(it) }
