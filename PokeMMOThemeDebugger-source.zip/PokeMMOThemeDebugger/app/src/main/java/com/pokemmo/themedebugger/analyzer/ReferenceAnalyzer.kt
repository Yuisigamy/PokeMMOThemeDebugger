package com.pokemmo.themedebugger.analyzer

import com.pokemmo.themedebugger.model.*

class ReferenceAnalyzer(private val baseline: ThemeVersion?) {
    fun resolve(definitions: List<ThemeDefinition>, references: List<ThemeReference>, files: List<ThemeFile>): List<Diagnostic> {
        val local = definitions.map { it.name }.toSet()
        val filePaths = files.map { normalize(it.path) }.toSet()
        val diagnostics = mutableListOf<Diagnostic>()
        references.forEach { ref ->
            val target = ref.target.trim()
            if (local.contains(target)) { ref.state = ReferenceState.LOCAL; return@forEach }
            val fileLike = target.substringAfterLast('/').contains('.') && (target.startsWith("/") || target.contains('/'))
            if (fileLike && filePaths.contains(normalize(target))) { ref.state = ReferenceState.LOCAL; return@forEach }
            if (baseline?.knownDefinitions?.contains(target) == true) {
                ref.state = ReferenceState.INHERITED
                diagnostics += Diagnostic(Severity.WARNING, "Referencia heredada", "No está definida localmente, pero existe en el baseline ${baseline.id}.", ref.location, detail = "Referencia: $target", suggestion = "Es válida si el Theme base activo corresponde a este baseline.")
            } else if (fileLike) {
                ref.state = ReferenceState.BROKEN
                diagnostics += Diagnostic(Severity.ERROR, "Referencia de recurso rota", "No existe el recurso referenciado en el ZIP.", ref.location, detail = "Referencia: $target", suggestion = "Comprueba la ruta y la extensión del recurso.")
            } else {
                ref.state = ReferenceState.BROKEN
                diagnostics += Diagnostic(Severity.ERROR, "Referencia no encontrada", "No se encontró una definición local ni una entrada conocida del baseline.", ref.location,
                    detail = "Referencia: $target", suggestion = "Puede ser un recurso eliminado, un nombre cambiado o una dependencia de otra versión. Compara contra el baseline adecuado antes de corregirlo.")
            }
        }
        return diagnostics
    }
    private fun normalize(p: String) = p.trimStart('/').replace('\\', '/')
}
