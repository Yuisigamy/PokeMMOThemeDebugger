package com.pokemmo.themedebugger.analyzer

import com.pokemmo.themedebugger.model.*
import java.io.InputStream
import java.util.zip.ZipFile

class ImageAnalyzer {
    data class Result(val infos: List<ImageInfo>, val diagnostics: List<Diagnostic>)
    fun validate(zip: ZipFile, files: List<ThemeFile>): Result {
        val infos = mutableListOf<ImageInfo>(); val diagnostics = mutableListOf<Diagnostic>()
        files.filter { it.kind == ResourceKind.IMAGE }.forEach { file ->
            try {
                zip.getInputStream(zip.getEntry(file.path)!!).use { input ->
                    val dims = readDimensions(input, file.extension)
                    if (dims == null) diagnostics += Diagnostic(Severity.ERROR, "Imagen inválida", "No se pudo reconocer o leer el encabezado de la imagen.", Location(file.path))
                    else { infos += ImageInfo(file.path, dims.first, dims.second, file.extension.uppercase()); diagnostics += Diagnostic(Severity.OK, "Imagen válida", "${dims.first}×${dims.second} ${file.extension.uppercase()}.", Location(file.path)) }
                }
            } catch (e: Exception) { diagnostics += Diagnostic(Severity.ERROR, "Imagen corrupta", e.message ?: "No se pudo leer la imagen.", Location(file.path)) }
        }
        return Result(infos, diagnostics)
    }
    private fun readDimensions(input: InputStream, ext: String): Pair<Int, Int>? {
        val b = input.readBytes()
        return when (ext.lowercase()) {
            "png" -> if (b.size >= 24 && b.copyOfRange(0, 8).contentEquals(byteArrayOf(137.toByte(),80,78,71,13,10,26,10))) Pair(readInt(b,16), readInt(b,20)) else null
            "jpg", "jpeg" -> jpegSize(b)
            "webp" -> webpSize(b)
            else -> null
        }
    }
    private fun readInt(b: ByteArray, i: Int) = ((b[i].toInt() and 255) shl 24) or ((b[i+1].toInt() and 255) shl 16) or ((b[i+2].toInt() and 255) shl 8) or (b[i+3].toInt() and 255)
    private fun jpegSize(b: ByteArray): Pair<Int,Int>? {
        if (b.size < 4 || b[0].toInt() != 0xFF || b[1].toInt() != 0xD8) return null
        var i = 2
        while (i + 9 < b.size) {
            if ((b[i].toInt() and 255) != 0xFF) { i++; continue }
            val marker = b[i+1].toInt() and 255
            if (marker == 0xD9 || marker == 0xDA) break
            val len = ((b[i+2].toInt() and 255) shl 8) or (b[i+3].toInt() and 255)
            if (len < 2 || i + 2 + len > b.size) return null
            if (marker in setOf(0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF)) {
                return Pair(((b[i+5].toInt() and 255) shl 8) or (b[i+6].toInt() and 255), ((b[i+7].toInt() and 255) shl 8) or (b[i+8].toInt() and 255))
            }
            i += 2 + len
        }
        return null
    }
    private fun webpSize(b: ByteArray): Pair<Int,Int>? {
        if (b.size < 30 || String(b,0,4) != "RIFF" || String(b,8,4) != "WEBP") return null
        return when (String(b,12,4)) {
            "VP8X" -> Pair(1 + ((b[24].toInt() and 255) or ((b[25].toInt() and 255) shl 8) or ((b[26].toInt() and 255) shl 16)), 1 + ((b[27].toInt() and 255) or ((b[28].toInt() and 255) shl 8) or ((b[29].toInt() and 255) shl 16)))
            else -> null
        }
    }
}
