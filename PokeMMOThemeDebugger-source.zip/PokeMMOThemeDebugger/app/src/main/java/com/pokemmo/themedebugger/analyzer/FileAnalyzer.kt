package com.pokemmo.themedebugger.analyzer

import com.pokemmo.themedebugger.model.*
import java.util.zip.ZipFile
import com.pokemmo.themedebugger.model.sha256

class FileAnalyzer {
    data class Result(val index: ThemeIndex, val diagnostics: List<Diagnostic>)

    fun index(zip: ZipFile): Result {
        val entries = zip.entries().asSequence().toList()
        val paths = entries.filterNot { it.isDirectory }.map { it.name }
        val duplicates = paths.groupingBy { it }.eachCount().filterValues { it > 1 }.keys
        val diagnostics = mutableListOf<Diagnostic>()
        if (duplicates.isNotEmpty()) diagnostics += duplicates.map {
            Diagnostic(Severity.WARNING, "Archivo duplicado", "El ZIP contiene más de una entrada con la ruta '$it'.", Location(it), suggestion = "Revisa el ZIP: PokeMMO puede resolver entradas duplicadas de forma no determinista.")
        }
        val invalid = paths.filter { path ->
            path.startsWith("/") || path.contains("\\") || path.split('/').any { it == ".." } || path.contains('\u0000')
        }
        diagnostics += invalid.map { Diagnostic(Severity.ERROR, "Ruta ZIP inválida", "La ruta contiene una construcción no segura o inesperada.", Location(it)) }
        val files = entries.filterNot { it.isDirectory }.map { e ->
            val ext = e.name.substringAfterLast('.', "").lowercase()
            val kind = when (ext) {
                "xml" -> ResourceKind.DEFINITION
                "png", "jpg", "jpeg", "webp" -> ResourceKind.IMAGE
                "ttf", "otf", "ttc" -> ResourceKind.FONT
                else -> ResourceKind.FILE
            }
            ThemeFile(e.name, e.size, ext, kind, zip.getInputStream(e).use { it.readBytes().sha256() }, duplicate = e.name in duplicates)
        }
        val xml = files.filter { it.extension == "xml" }.map { it.path }
        val images = files.filter { it.kind == ResourceKind.IMAGE }
        val fonts = files.filter { it.kind == ResourceKind.FONT }
        val atlases = xml.filter { it.substringAfterLast('/').lowercase().contains("gfx") || it.substringAfterLast('/').lowercase().contains("atlas") }
        return Result(ThemeIndex(files, xml, images, fonts, atlases, files.filter { it.kind == ResourceKind.FILE }, duplicates), diagnostics)
    }
}
