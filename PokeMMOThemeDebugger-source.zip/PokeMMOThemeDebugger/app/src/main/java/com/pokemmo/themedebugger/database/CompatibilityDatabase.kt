package com.pokemmo.themedebugger.database

import com.pokemmo.themedebugger.model.ThemeVersion

class CompatibilityDatabaseFacade(private val repository: VersionRepository) {
    fun get(id: String): ThemeVersion? = repository.find(id)
    fun versions(): List<ThemeVersion> = repository.all()
}
