package com.pokemmo.themedebugger.database

import android.content.Context
import com.pokemmo.themedebugger.model.ThemeVersion
import org.json.JSONObject
import java.io.File

class VersionRepository(private val context: Context) {
    fun all(): List<ThemeVersion> = (listOf("a8d7102") + storedIds()).distinct().mapNotNull { find(it) }
    fun find(id: String): ThemeVersion? = runCatching {
        val stored = File(context.filesDir, "compatibility/versions/$id/manifest.json")
        val text = if (stored.exists()) stored.readText() else context.assets.open("compatibility/versions/$id/manifest.json").bufferedReader().use { it.readText() }
        val json = JSONObject(text)
        ThemeVersion(json.getString("id"), json.getString("label"), json.getString("fullCommit"), json.getString("source"),
            buildSet { json.optJSONArray("knownDefinitions")?.let { a -> for (i in 0 until a.length()) add(a.getString(i)) } },
            buildList { json.optJSONArray("notes")?.let { a -> for (i in 0 until a.length()) add(a.getString(i)) } })
    }.getOrNull()
    fun importManifest(jsonText: String): ThemeVersion {
        val json = JSONObject(jsonText)
        val id = json.getString("id")
        val target = File(context.filesDir, "compatibility/versions/$id/manifest.json")
        target.parentFile?.mkdirs(); target.writeText(jsonText)
        return find(id) ?: error("Manifest inválido")
    }
    private fun storedIds(): List<String> = File(context.filesDir, "compatibility/versions").listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()
}

class CompatibilityDatabase(private val repository: VersionRepository) {
    fun baseline(id: String) = repository.find(id)
}
