package com.pokemmo.themedebugger.analyzer

import com.pokemmo.themedebugger.model.*
import org.xml.sax.*
import org.xml.sax.helpers.DefaultHandler
import java.io.InputStream
import java.util.zip.ZipFile
import javax.xml.parsers.SAXParserFactory

class XmlAnalyzer {
    data class Result(
        val files: List<ThemeFile>,
        val definitions: List<ThemeDefinition>,
        val references: List<ThemeReference>,
        val regions: List<AtlasRegion>,
        val images: List<ImageInfo>,
        val fonts: List<FontInfo>,
        val diagnostics: List<Diagnostic>
    )

    fun parse(zip: ZipFile, index: ThemeIndex): Result {
        val definitions = mutableListOf<ThemeDefinition>()
        val refs = mutableListOf<ThemeReference>()
        val regions = mutableListOf<AtlasRegion>()
        val images = mutableListOf<ImageInfo>()
        val fonts = mutableListOf<FontInfo>()
        val diagnostics = mutableListOf<Diagnostic>()
        val factory = SAXParserFactory.newInstance().apply { isNamespaceAware = false }
        index.xmlFiles.forEach { path ->
            zip.getEntry(path)?.let { entry ->
                try {
                    zip.getInputStream(entry).use { input ->
                        val handler = ThemeSaxHandler(path, definitions, refs, regions, images, fonts)
                        factory.newSAXParser().parse(InputSource(input), handler)
                    }
                    diagnostics += Diagnostic(Severity.OK, "XML válido", "XML parseado correctamente.", Location(path))
                } catch (e: SAXParseException) {
                    diagnostics += Diagnostic(
                        Severity.ERROR, "XML inválido", e.message ?: "Error de XML", Location(path, e.lineNumber.takeIf { it > 0 }, e.columnNumber.takeIf { it > 0 }),
                        fragment = e.message
                    )
                } catch (e: Exception) {
                    diagnostics += Diagnostic(Severity.ERROR, "No se pudo analizar XML", e.message ?: e.javaClass.simpleName, Location(path))
                }
            }
        }
        val duplicates = definitions.groupBy { it.name }.filterValues { it.size > 1 }
        duplicates.forEach { (name, defs) ->
            val overwriteCount = defs.count { it.overwrite }
            val severity = if (overwriteCount == defs.size - 1 && defs.any { it.overwrite }) Severity.WARNING else Severity.ERROR
            diagnostics += Diagnostic(
                severity,
                if (severity == Severity.WARNING) "Posible sobrescritura intencional" else "Definición duplicada",
                "'$name' aparece ${defs.size} veces.",
                defs[1].location,
                detail = defs.joinToString("; ") { it.location.toString() },
                suggestion = if (severity == Severity.WARNING) "Revisa que overwrite=true sea intencional." else "Renombra la definición o usa el mecanismo de sobrescritura soportado por el Theme."
            )
        }
        return Result(index.files, definitions, refs, regions, images, fonts, diagnostics)
    }

    private class ThemeSaxHandler(
        private val path: String,
        private val definitions: MutableList<ThemeDefinition>,
        private val refs: MutableList<ThemeReference>,
        private val regions: MutableList<AtlasRegion>,
        private val images: MutableList<ImageInfo>,
        private val fonts: MutableList<FontInfo>
    ) : DefaultHandler() {
        private var locator: Locator? = null
        private var atlasFile: String? = null
        private var textBuffer: StringBuilder? = null
        private var textElement: String? = null
        private val stack = ArrayDeque<String>()

        override fun setDocumentLocator(locator: Locator) { this.locator = locator }
        private fun loc() = Location(path, locator?.lineNumber?.takeIf { it > 0 }, locator?.columnNumber?.takeIf { it > 0 })
        private fun attr(a: Attributes, key: String) = a.getValue(key)

        override fun startElement(uri: String?, localName: String?, qName: String, a: Attributes) {
            stack.add(qName)
            val name = attr(a, "name")
            val ref = attr(a, "ref")
            val overwrite = attr(a, "overwrite")?.equals("true", true) == true
            val kind = when (qName.lowercase()) {
                "fontdef" -> ResourceKind.FONT
                "area", "grid", "select", "alias", "animation", "composed", "theme" -> ResourceKind.DEFINITION
                else -> null
            }
            if (name != null && kind != null && qName.lowercase() != "area" || (name != null && qName.equals("area", true))) {
                definitions += ThemeDefinition(name, if (qName.equals("area", true) && atlasFile != null) ResourceKind.ATLAS else kind ?: ResourceKind.DEFINITION, loc(), path, ref, overwrite,
                    buildMap { for (i in 0 until a.length) put(a.getQName(i), a.getValue(i)) })
            }
            if (ref != null) {
                refs += ThemeReference(ref, ResourceKind.DEFINITION, loc(), path, "ref=\"$ref\"")
            }
            if (qName.equals("images", true)) atlasFile = attr(a, "file")
            if (qName.equals("area", true) && atlasFile != null) {
                val xywh = attr(a, "xywh")
                if (xywh != null) parseRegion(xywh, name)
            }
            if (qName.equals("image", true) || qName.equals("font", true)) {
                textElement = qName.lowercase(); textBuffer = StringBuilder()
            }
            if (qName.equals("fontdef", true)) fonts += FontInfo(
                ThemeDefinition(name ?: "<unnamed>", ResourceKind.FONT, loc(), path, ref, overwrite), attr(a, "filename")
            )
        }

        private fun parseRegion(xywh: String, name: String?) {
            if (xywh == "*") return
            val p = xywh.split(',').mapNotNull { it.trim().toIntOrNull() }
            if (p.size == 4) regions += AtlasRegion(name, atlasFile!!, loc(), p[0], p[1], p[2], p[3])
        }

        override fun characters(ch: CharArray, start: Int, length: Int) { textBuffer?.append(ch, start, length) }
        override fun endElement(uri: String?, localName: String?, qName: String) {
            if (textElement == qName.lowercase()) {
                val value = textBuffer?.toString()?.trim().orEmpty()
                if (value.isNotEmpty()) refs += ThemeReference(value, if (qName.equals("font", true)) ResourceKind.FONT else ResourceKind.IMAGE, loc(), path, "<$qName>...</$qName>")
                textElement = null; textBuffer = null
            }
            if (qName.equals("images", true)) atlasFile = null
            if (stack.isNotEmpty()) stack.removeLast()
        }
    }
}
