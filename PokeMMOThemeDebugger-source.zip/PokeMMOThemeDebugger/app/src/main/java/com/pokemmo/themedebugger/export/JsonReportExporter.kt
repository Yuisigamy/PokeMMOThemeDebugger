package com.pokemmo.themedebugger.export

import com.pokemmo.themedebugger.model.*
import org.json.JSONArray
import org.json.JSONObject

object JsonReportExporter {
    fun export(report: AnalysisReport): String {
        val root = JSONObject().apply {
            put("theme", report.snapshot.name)
            put("baseline", report.baseline?.id ?: JSONObject.NULL)
            put("files", report.snapshot.index.files.size)
            put("xml", report.snapshot.index.xmlFiles.size)
            put("definitions", report.definitionCount)
            put("errors", report.errors.size)
            put("warnings", report.warnings.size)
            put("diagnostics", JSONArray().apply {
                report.snapshot.diagnostics.forEach { d -> put(JSONObject().apply {
                    put("severity", d.severity.name); put("title", d.title); put("message", d.message)
                    d.location?.let { put("file", it.file); it.line?.let { n -> put("line", n) }; it.column?.let { n -> put("column", n) } }
                    d.detail?.let { put("detail", it) }; d.suggestion?.let { put("suggestion", it) }; d.fragment?.let { put("fragment", it) }
                }) }
            })
        }
        return root.toString(2)
    }
}
