# PokeMMO Theme Debugger

Aplicación Android nativa en Kotlin + Jetpack Compose para analizar localmente ZIPs de Themes de PokeMMO. No ejecuta PokeMMO ni necesita sus logs.

## Estado del proyecto

La primera versión implementa:

- selección mediante Android Storage Access Framework;
- índice de ZIP sin modificar el original;
- detección de entradas duplicadas y rutas sospechosas;
- parser SAX de todos los XML con línea/columna;
- extracción de `ref`, `<image>`, `<font>`, `fontDef`, `theme`, Atlas, `area`, `grid`, `alias`, `animation`, `frame`, `select` y `composed`;
- resolución local/heredada/rota de referencias;
- análisis de dimensiones de PNG/JPEG/WEBP;
- validación de regiones Atlas contra dimensiones conocidas;
- análisis de fuentes y herencia mediante `ref`;
- comparación contra un segundo ZIP;
- baseline de compatibilidad `a8d7102` como metadatos conservadores;
- exportación TXT y JSON;
- tests unitarios para XML, referencias, herencia, Atlas, fuentes y duplicados, con fixtures artificiales en `app/src/test/resources/fixtures/`.

No se inventan reglas para sintaxis que no pueda demostrarse. Las comprobaciones conservadoras se reportan como WARNING/INFO.

## Fuentes del baseline

El baseline inicial es el commit `a8d7102558b3333addc3050856f72acd7312ecf8` del repositorio oficial `PokeMMO/PokeMMO_Mods`, cuyo `theme_history/` contiene los Themes base. El archivo `app/src/main/assets/compatibility/versions/a8d7102/manifest.json` mantiene la metadata y el conjunto de definiciones conocidas.

La aplicación no descarga el Theme oficial automáticamente ni sube Themes del usuario. El ZIP del usuario se analiza localmente.

## Abrir en Android Studio

1. Abre la carpeta `PokeMMOThemeDebugger`.
2. Espera la sincronización Gradle.
3. Selecciona un dispositivo/emulador Android 8.0+.
4. Ejecuta la configuración `app`.

## Compilar

```bash
gradle assembleDebug
```

APK debug:

`app/build/outputs/apk/debug/app-debug.apk`

Release:

```bash
gradle assembleRelease
```

APK release:

`app/build/outputs/apk/release/app-release.apk`

Si quieres usar Gradle Wrapper, en una máquina con Gradle instalado ejecuta `gradle wrapper --gradle-version 8.10.2` y conserva los archivos generados.

Para distribución real, configura firma en Android Studio/Gradle antes de usar `assembleRelease`.

## Instalar APK

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Actualizar la base de compatibilidad

La arquitectura usa `app/src/main/assets/compatibility/versions/<id>/manifest.json`. Añade una nueva carpeta, conserva el SHA completo del commit y registra definiciones verificadas. No sustituyas el baseline anterior: cada versión debe poder coexistir.

Una futura actualización online puede descargar estos manifiestos, pero el analizador no depende de Internet.

## Añadir una nueva versión de PokeMMO

1. Crea `app/src/main/assets/compatibility/versions/<short-sha>/`.
2. Añade `manifest.json` con `id`, `fullCommit`, `label`, `source`, `knownDefinitions`, reglas confirmadas y notas.
3. Si se dispone de un snapshot completo del Theme base, puede añadirse un índice de recursos separado sin incluir activos propietarios innecesarios.
4. Añade tests de las reglas nuevas.
5. Actualiza `VersionRepository` si se quiere incluir la versión como opción visible.

## Interpretación de diagnósticos

- **CRITICAL**: fallo que impide confiar en el análisis.
- **ERROR**: problema con evidencia suficiente para considerarlo roto.
- **WARNING**: posible incompatibilidad, herencia o sobrescritura que requiere contexto.
- **INFO**: comportamiento detectado que no debe marcarse como error automáticamente.
- **OK**: comprobación confirmada.

Una referencia no local no se considera automáticamente rota si coincide con una definición conocida del baseline. En ese caso se informa como **Referencia heredada**.

## Privacidad

No hay permiso de Internet en el Manifest. El ZIP se lee desde el Storage Access Framework y se procesa localmente. Se utiliza almacenamiento privado/cache para operaciones temporales; el archivo original no se modifica.

## Limitaciones deliberadas

El formato de Themes tiene mecanismos que no están formalmente documentados en un esquema público único. Por ello, el parser es tolerante y extensible. No se marca como error cualquier atributo desconocido ni cualquier `xywh` negativo: el baseline oficial contiene ejemplos que justifican esta precaución.

## Próximas extensiones preparadas

La separación por módulos permite añadir visor Atlas, preview, diff visual, historial, reparación y actualización de la base sin acoplar esas funciones al parser central.
